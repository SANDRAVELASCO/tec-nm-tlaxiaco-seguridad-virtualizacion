<?php
$conexion = new mysqli("localhost","root","","secure_db");
$conexion->set_charset("utf8");
?>