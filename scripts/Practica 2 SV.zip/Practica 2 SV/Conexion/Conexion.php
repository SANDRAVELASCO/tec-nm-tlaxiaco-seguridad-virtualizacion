<?php
$conexion = new mysqli("localhost","root","","practica2");
$conexion->set_charset("utf8");
?>