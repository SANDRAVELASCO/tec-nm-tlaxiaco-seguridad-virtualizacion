document.getElementById("registerForm").addEventListener("submit", (e) => {
    e.preventDefault();

    const password = document.getElementById("password").value;
    const confirmPassword = document.getElementById("confirmPassword").value;

    if (password !== confirmPassword) {
        alert("Las contraseñas no coinciden");
        return;
    }

    if (!/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/.test(password)) {
        alert("La contraseña debe tener al menos 8 caracteres e incluir mayúsculas, minúsculas, números y símbolos.");
        return;
    }

    alert("La contraseña es segura!");
   
});

// script.js

function generarContraseña() {
    const nombreCompleto = document.getElementById('nombre').value;
    const añoNacimiento = document.getElementById('anoNacimiento').value;
    const mesNacimiento = document.getElementById('mesNacimiento').value;
    const diaNacimiento = document.getElementById('diaNacimiento').value;

    if (!nombreCompleto || !añoNacimiento || !mesNacimiento || !diaNacimiento) {
        alert("Por favor, llena todos los campos.");
        return;
    }

    let partesNombre = nombreCompleto.split(' ');
    let nombre = partesNombre[0].charAt(0).toUpperCase(); // Primera letra del primer nombre
    let apellido = partesNombre[partesNombre.length - 1].toUpperCase().slice(0, 3); // Primeras tres letras del apellido

    let año = añoNacimiento.toString().slice(-2); // Últimos dos dígitos del año
    let mes = (mesNacimiento < 10 ? '0' + mesNacimiento : mesNacimiento); // Mes con dos dígitos
    let dia = (diaNacimiento < 10 ? '0' + diaNacimiento : diaNacimiento); // Día con dos dígitos

    // Crear una contraseña compleja de al menos 12 caracteres
    let contraseñaBase = nombre + apellido + año + mes + dia;
    while (contraseñaBase.length < 12) {
        contraseñaBase += Math.floor(Math.random() * 10); // Añadir números aleatorios si es necesario
    }

    // Mezclar la contraseña con caracteres especiales, mayúsculas, minúsculas y números
    let caracteresEspeciales = ['!', '@', '#', '$', '%', '&', '*', '(', ')'];
    let contraseñaSegura = contraseñaBase;

    // Incluir un símbolo aleatorio al final
    let simboloAleatorio = caracteresEspeciales[Math.floor(Math.random() * caracteresEspeciales.length)];
    contraseñaSegura += simboloAleatorio;

    // Convertir algunos caracteres a minúsculas o mayúsculas aleatoriamente
    contraseñaSegura = contraseñaSegura.split('').map((char, index) => {
        if (Math.random() > 0.5) {
            return char.toUpperCase();
        }
        return char.toLowerCase();
    }).join('');

    // Mostrar la contraseña recomendada
    document.getElementById('contraseña').textContent = contraseñaSegura;
}
